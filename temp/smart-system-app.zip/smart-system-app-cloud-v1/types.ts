export enum UserRole {
  OWNER = 'OWNER',
  EMPLOYEE = 'EMPLOYEE',
  DEVELOPER = 'DEVELOPER'
}

export enum EmployeeType {
  ACCOUNTANT = 'ACCOUNTANT',
  FIELD_AGENT = 'FIELD_AGENT'
}

export enum LicenseStatus {
  READY = 'READY',
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED',
  EXPIRED = 'EXPIRED'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  employeeType?: EmployeeType;
  ownerId: string; // إلزامي لكل مستخدم
  phone: string;
  licenseStatus?: LicenseStatus;
  status?: 'active' | 'suspended';
  licenseKey?: string;
  expiryDate?: number;
}

export interface Product {
  id: string;
  ownerId: string; 
  name: string;
  costPrice: number;
  basePrice: number;
  stock: number;
  minStock: number;
  category: string;
  unit: string;
  isDeleted: boolean;
}

export interface Customer {
  id: string;
  ownerId: string; 
  name: string;
  phone: string;
  balance: number; // Immutable from client rules
  isDeleted: boolean;
}

export interface SaleInvoice {
  id: string;
  ownerId: string;
  distributorId: string;
  customerId: string;
  customerName: string;
  items: any[];
  grandTotal: number;
  paymentType: 'CASH' | 'CREDIT';
  timestamp: number;
}

export interface Payment {
  id: string;
  ownerId: string;
  distributorId: string;
  customerId: string;
  amount: number;
  timestamp: number;
}

export interface License {
  id: string;
  licenseKey: string;
  status: LicenseStatus;
  orgName: string;
  ownerId: string | null;
  issuedAt: number;
  type: 'TRIAL' | 'PERMANENT';
  expiryDate?: string;
}