
import React, { useState } from 'react';
import { useApp } from '../store';
import { EmployeeType } from '../types';
import { Plus, Receipt, Calculator, Users, CheckCircle2, AlertCircle } from 'lucide-react';

export const DistributorView: React.FC = () => {
  const { user, products, customers, sales, addCustomer, submitInvoice, submitPayment, addNotification } = useApp();
  const [activeMode, setActiveMode] = useState<'invoice' | 'payment' | 'customers'>('invoice');
  const [selectedCust, setSelectedCust] = useState('');
  const [selectedSale, setSelectedSale] = useState('');
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isReadOnly = user?.employeeType === EmployeeType.ACCOUNTANT;

  const handleInvoice = async () => {
    if (isReadOnly || !selectedCust || isSubmitting) return;
    setIsSubmitting(true);
    try {
      const customer = customers.find(c => c.id === selectedCust);
      await submitInvoice({
        customerId: selectedCust,
        customerName: customer?.name || 'غير معروف',
        grandTotal: 0, // Should be calculated if items were selected
        items: [],
        paymentType: 'CASH'
      });
      setIsSuccess(true);
    } catch (e: any) {
      addNotification("خطأ في إنشاء الفاتورة", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePayment = async () => {
    if (isReadOnly || !selectedSale || paymentAmount <= 0 || isSubmitting) return;
    setIsSubmitting(true);
    try {
      await submitPayment({
        saleId: selectedSale,
        amount: paymentAmount,
        notes: 'تحصيل ميداني'
      });
      setIsSuccess(true);
    } catch (e: any) {
      addNotification("خطأ في تسجيل الدفعة", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) return (
    <div className="flex flex-col items-center justify-center p-10 text-center animate-in zoom-in">
      <CheckCircle2 size={64} className="text-emerald-500 mb-4" />
      <h2 className="text-2xl font-black">تمت العملية بنجاح</h2>
      <button onClick={() => setIsSuccess(false)} className="mt-6 bg-slate-900 text-white px-8 py-3 rounded-xl font-bold">متابعة العمل</button>
    </div>
  );

  return (
    <div className="max-w-xl mx-auto space-y-6" dir="rtl">
      <div className="flex bg-white p-2 rounded-2xl shadow-sm border gap-2 overflow-x-auto">
        <button onClick={() => setActiveMode('invoice')} className={`flex-1 py-3 rounded-xl font-black text-xs ${activeMode === 'invoice' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>فواتير</button>
        <button onClick={() => setActiveMode('payment')} className={`flex-1 py-3 rounded-xl font-black text-xs ${activeMode === 'payment' ? 'bg-emerald-600 text-white' : 'text-slate-400'}`}>تحصيل</button>
        <button onClick={() => setActiveMode('customers')} className={`flex-1 py-3 rounded-xl font-black text-xs ${activeMode === 'customers' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}>الزبائن</button>
      </div>

      <div className="bg-white p-6 rounded-[2rem] border shadow-sm space-y-4">
        <label className="text-[10px] font-black text-slate-400 uppercase mr-2">اختيار الزبون</label>
        <select value={selectedCust} onChange={e => {
          setSelectedCust(e.target.value);
          setSelectedSale(''); // Reset selected sale when customer changes
        }} className="w-full p-4 bg-slate-50 rounded-xl font-black border-none outline-none">
          <option value="">-- ابحث عن زبون --</option>
          {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>

        {activeMode === 'payment' && selectedCust && (
          <>
            <label className="text-[10px] font-black text-slate-400 uppercase mr-2">اختيار الفاتورة المراد تحصيلها</label>
            <select value={selectedSale} onChange={e => setSelectedSale(e.target.value)} className="w-full p-4 bg-slate-50 rounded-xl font-black border-none outline-none">
              <option value="">-- اختر الفاتورة --</option>
              {sales.filter(s => s.customer_id === selectedCust && !s.is_voided).map(s => (
                <option key={s.id} value={s.id}>فاتورة #{s.id.slice(0,8)} - القيمة: {s.grand_total}</option>
              ))}
            </select>
            <label className="text-[10px] font-black text-slate-400 uppercase mr-2">المبلغ المراد تحصيله</label>
            <input 
              type="number" 
              placeholder="0" 
              className="w-full p-4 bg-slate-50 rounded-xl font-black border-none outline-none"
              value={paymentAmount || ''}
              onChange={e => setPaymentAmount(Number(e.target.value))}
            />
          </>
        )}
      </div>

      {isReadOnly ? (
        <div className="bg-amber-50 p-6 rounded-[1.5rem] border border-amber-200 flex items-center gap-4 text-amber-700">
          <AlertCircle />
          <p className="text-xs font-bold leading-relaxed">أنت في وضع "المحاسب المالي". يمكنك استعراض البيانات فقط ولا تملك صلاحية إنشاء فواتير أو تحصيلات.</p>
        </div>
      ) : (
        <>
          {activeMode === 'invoice' && (
            <button 
              onClick={handleInvoice} 
              disabled={isSubmitting || !selectedCust}
              className="w-full py-5 bg-blue-600 text-white rounded-[1.5rem] font-black shadow-xl shadow-blue-200 disabled:opacity-50 active:scale-95 transition-all"
            >
              {isSubmitting ? 'جاري الاعتماد...' : 'اعتماد فاتورة جديدة'}
            </button>
          )}
          {activeMode === 'payment' && (
            <button 
              onClick={handlePayment} 
              disabled={isSubmitting || !selectedSale || paymentAmount <= 0}
              className="w-full py-5 bg-emerald-600 text-white rounded-[1.5rem] font-black shadow-xl shadow-emerald-200 disabled:opacity-50 active:scale-95 transition-all"
            >
              {isSubmitting ? 'جاري تسجيل الدفعة...' : 'تسجيل التحصيل المالي'}
            </button>
          )}
        </>
      )}
    </div>
  );
};
