import React from 'react';
import { useApp } from '../store';
import { UserRole, LicenseStatus } from '../types';
import { ShieldAlert } from 'lucide-react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout, organization } = useApp();

  // إذا ما في مستخدم → اعرض صفحات الدخول عادي
  if (!user) {
    return <>{children}</>;
  }

  /**
   * ⚠️ حماية من خصائص غير موجودة
   * الترخيص يجب أن يأتي من organization أو license لاحقًا
   */
  const licenseStatus = (organization as any)?.licenseStatus;
  const expiryDate = (organization as any)?.expiryDate;

  const isSuspended =
    licenseStatus === LicenseStatus.SUSPENDED;

  const isExpired =
    typeof expiryDate === 'number' && expiryDate < Date.now();

  if ((isSuspended || isExpired) && user.role !== UserRole.DEVELOPER) {
    return (
      <div
        className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-center"
        dir="rtl"
      >
        <div className="max-w-md space-y-6 animate-in zoom-in duration-300">
          <div
            className={`w-24 h-24 rounded-[2.5rem] flex items-center justify-center text-white shadow-2xl mx-auto mb-8 ${
              isExpired ? 'bg-orange-500' : 'bg-red-500'
            }`}
          >
            <ShieldAlert size={48} />
          </div>

          <h2 className="text-3xl font-black text-white">
            {isExpired ? 'انتهت فترة التجربة' : 'الترخيص موقوف مؤقتاً'}
          </h2>

          <p className="text-slate-400 font-bold text-lg">
            {isExpired
              ? 'لقد انتهت الفترة الممنوحة لاستخدام النظام. يرجى مراجعة القسم المالي للتحويل إلى الترخيص الدائم.'
              : 'يرجى مراجعة القسم المالي لتسوية المستحقات وإعادة تفعيل الخدمة.'}
          </p>

          <div className="pt-8 flex flex-col gap-3">
            <a
              href="tel:09xxxxxxx"
              className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black shadow-xl transition-transform active:scale-95"
            >
              اتصل بالإدارة المالية
            </a>

            <button
              onClick={logout}
              className="w-full py-4 bg-white/10 text-white/60 rounded-2xl font-black"
            >
              تسجيل الخروج
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex bg-slate-50 text-right overflow-x-hidden font-['Tajawal']"
      dir="rtl"
    >
      <main className="flex-1 relative">
        <div className="p-4 md:p-8">{children}</div>
      </main>
    </div>
  );
};