import React from 'react';
import { useApp } from '../store';
import { CURRENCY } from '../constants';
import { 
  TrendingUp, Activity, Users, ArrowRightLeft, X, Box, 
  LayoutDashboard, Wallet, UserPlus, ShieldCheck, Copy, 
  CheckCircle2, Trash2, Calendar, Search, AlertCircle,
  LogOut, Receipt, ArrowUpRight, Briefcase, RotateCcw, 
  LineChart as ChartIcon, Sparkles, ShoppingCart, Plus
} from 'lucide-react';
import { UserRole, EmployeeType } from '../types';
import { AdminPanel } from './AdminPanel';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer 
} from 'recharts';

export const OwnerDashboard: React.FC = () => {
  const { sales = [], payments = [], products = [], users = [], customers = [], logout, addDistributor } = useApp();
  const [activeTab, setActiveTab] = React.useState<'daily' | 'team' | 'inventory' | 'finance' | 'customers'>('daily');
  const [showAddUserModal, setShowAddUserModal] = React.useState(false);
  const [copiedId, setCopiedId] = React.useState<string | null>(null);
  const [isMounted, setIsMounted] = React.useState(false);

  React.useEffect(() => {
    setIsMounted(true);
  }, []);

  const stats = React.useMemo(() => {
    const todayStart = new Date().setHours(0,0,0,0);
    const todaySales = sales.filter(s => s.timestamp >= todayStart);
    const todayRevenue = todaySales.reduce((s, i) => s + i.grandTotal, 0);
    const totalCollections = payments.filter(c => c.timestamp >= todayStart).reduce((s, i) => s + i.amount, 0);

    const chartData = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const sOfDay = new Date(d).setHours(0,0,0,0);
      const eOfDay = new Date(d).setHours(23,59,59,999);
      const daySales = sales.filter(s => s.timestamp >= sOfDay && s.timestamp <= eOfDay);
      return { 
        day: d.toLocaleDateString('ar-EG', { weekday: 'short' }), 
        revenue: daySales.reduce((s, v) => s + v.grandTotal, 0) 
      };
    });

    return { todayRevenue, totalCollections, chartData };
  }, [sales, payments]);

  const teamMembers = users.filter(u => u.role === UserRole.EMPLOYEE);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-24 text-right animate-in fade-in" dir="rtl">
      <div className="flex items-center justify-between bg-white px-5 py-4 rounded-[1.8rem] shadow-sm border mx-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white"><ShieldCheck size={20} /></div>
          <div>
            <h1 className="text-lg font-black text-slate-900 leading-none">لوحة المالك</h1>
            <p className="text-slate-400 text-[9px] font-bold mt-1">الإدارة المالية الذكية</p>
          </div>
        </div>
        <button onClick={logout} className="w-10 h-10 flex items-center justify-center bg-red-50 text-red-500 rounded-xl active:scale-90"><LogOut size={20} /></button>
      </div>

      <div className="sticky top-2 z-[100] mx-2 flex bg-white/80 backdrop-blur-lg p-1 rounded-2xl border shadow-xl overflow-x-auto gap-1">
         <TabBtn active={activeTab === 'daily'} onClick={() => setActiveTab('daily')} icon={<LayoutDashboard size={18}/>} label="الرئيسية" />
         <TabBtn active={activeTab === 'finance'} onClick={() => setActiveTab('finance')} icon={<TrendingUp size={18}/>} label="المالية" />
         <TabBtn active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} icon={<Box size={18}/>} label="المخزن" />
         <TabBtn active={activeTab === 'team'} onClick={() => setActiveTab('team')} icon={<Users size={18}/>} label="الموظفين" />
         <TabBtn active={activeTab === 'customers'} onClick={() => setActiveTab('customers')} icon={<Briefcase size={18}/>} label="الزبائن" />
      </div>

      <div className="px-2 space-y-4">
        {activeTab === 'daily' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
               <KpiCard label="مبيعات اليوم" value={stats.todayRevenue.toLocaleString()} color="blue" icon={<Receipt size={18}/>} />
               <KpiCard label="التحصيل" value={stats.totalCollections.toLocaleString()} color="indigo" icon={<Wallet size={18}/>} />
            </div>
            <div className="bg-white p-6 rounded-[2.5rem] border shadow-sm h-72">
               {isMounted && (
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={stats.chartData}>
                      <defs>
                        <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                          <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700}} />
                      <Tooltip contentStyle={{ borderRadius: '16px', border: 'none' }} />
                      <Area type="monotone" dataKey="revenue" stroke="#2563eb" fillOpacity={1} fill="url(#colorRev)" strokeWidth={3} />
                    </AreaChart>
                 </ResponsiveContainer>
               )}
            </div>
          </div>
        )}

        {activeTab === 'team' && (
          <div className="space-y-4">
             <button onClick={() => setShowAddUserModal(true)} className="w-full py-5 bg-blue-600 text-white rounded-[1.8rem] font-black text-sm flex items-center justify-center gap-2 shadow-xl">
                <UserPlus size={18}/> إضافة موظف (محاسب / موزع)
             </button>
             <div className="grid grid-cols-1 gap-3">
                {teamMembers.map(u => (
                  <div key={u.id} className="bg-white p-5 rounded-[2.2rem] border shadow-sm flex justify-between items-center">
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-blue-600"><Users size={24}/></div>
                        <div>
                          <p className="font-black text-slate-800 text-sm">{u.name}</p>
                          <p className="text-[9px] font-black text-slate-400 uppercase">
                            {u.employeeType === EmployeeType.FIELD_AGENT ? 'موزع ميداني' : 'محاسب مالي'}
                          </p>
                        </div>
                     </div>
                     <button onClick={() => copyToClipboard(u.licenseKey || '', u.id)} className={`p-3 rounded-xl ${copiedId === u.id ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                        {copiedId === u.id ? <CheckCircle2 size={18}/> : <Copy size={18}/>}
                     </button>
                  </div>
                ))}
             </div>
          </div>
        )}
        
        {activeTab === 'inventory' && <AdminPanel />}
        
        {activeTab === 'customers' && (
          <div className="space-y-3">
             <div className="bg-red-500 p-6 rounded-[2.5rem] text-white shadow-xl">
                <p className="text-[10px] font-black opacity-60 mb-1">إجمالي ذمم السوق</p>
                <p className="text-3xl font-black">{customers.reduce((s, c) => s + c.balance, 0).toLocaleString()} {CURRENCY}</p>
             </div>
             {customers.map(c => (
               <div key={c.id} className="bg-white p-5 rounded-[2.2rem] border shadow-sm flex justify-between items-center">
                  <p className="font-black text-slate-800 text-sm">{c.name}</p>
                  <p className={`font-black text-sm ${c.balance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>{c.balance.toLocaleString()} {CURRENCY}</p>
               </div>
             ))}
          </div>
        )}
      </div>

      {showAddUserModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[500] flex items-end sm:items-center justify-center">
           <div className="bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] w-full max-w-md p-8 space-y-6">
             <div className="flex justify-between items-center">
               <h2 className="text-xl font-black">إضافة موظف جديد</h2>
               <button onClick={() => setShowAddUserModal(false)} className="p-2 bg-slate-100 rounded-full"><X size={20}/></button>
             </div>
             <form onSubmit={(e) => { 
               e.preventDefault(); 
               const fd = new FormData(e.currentTarget); 
               addDistributor(fd.get('name') as string, fd.get('phone') as string, UserRole.EMPLOYEE, fd.get('type') as EmployeeType); 
               setShowAddUserModal(false); 
             }} className="space-y-4">
               <input name="name" required placeholder="اسم الموظف" className="w-full bg-slate-50 border p-4 rounded-xl font-bold text-right" />
               <input name="phone" required placeholder="رقم الهاتف" className="w-full bg-slate-50 border p-4 rounded-xl font-bold text-right" />
               <select name="type" className="w-full bg-slate-50 border p-4 rounded-xl font-bold text-right">
                 <option value={EmployeeType.FIELD_AGENT}>موزع ميداني (Field Agent)</option>
                 <option value={EmployeeType.ACCOUNTANT}>محاسب مالي (Accountant)</option>
               </select>
               <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black">توليد كود التفعيل</button>
             </form>
           </div>
        </div>
      )}
    </div>
  );
};

const TabBtn: React.FC<any> = ({ active, onClick, icon, label }) => (
  <button onClick={onClick} className={`flex-1 flex flex-col items-center justify-center gap-1.5 px-2 py-3.5 rounded-[1.8rem] text-[9px] font-black transition-all ${active ? 'bg-slate-900 text-white shadow-2xl' : 'text-slate-400 hover:text-slate-600'}`}>
    {icon} <span>{label}</span>
  </button>
);

const KpiCard: React.FC<any> = ({ label, value, color, icon }) => (
  <div className="bg-white p-6 rounded-[2.5rem] border shadow-sm flex flex-col gap-5 text-right">
    <div className={`p-3 rounded-2xl w-fit ${color === 'blue' ? 'bg-blue-50 text-blue-600' : 'bg-indigo-50 text-indigo-600'}`}>{icon}</div>
    <div>
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">{label}</span>
      <p className="text-2xl font-black text-slate-900 leading-none">{value} <span className="text-[11px] font-medium opacity-20">{CURRENCY}</span></p>
    </div>
  </div>
);
