import React from 'react';
import { useApp } from '../store';
import { CURRENCY } from '../constants';
import { Receipt, DollarSign, Users } from 'lucide-react';

export const AccountantView: React.FC = () => {
  const { sales, payments, customers } = useApp();

  return (
    <div className="max-w-4xl mx-auto space-y-6" dir="rtl">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-black text-slate-800 tracking-tight">التدقيق المالي (نمط العرض)</h1>
        <p className="text-slate-400 text-xs font-bold">متابعة دقيقة لكافة العمليات المالية للمنشأة.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard label="المبيعات" val={sales.reduce((s,i) => s + i.grandTotal, 0)} icon={<Receipt/>} color="blue" />
        <StatCard label="التحصيلات" val={payments.reduce((s,i) => s + i.amount, 0)} icon={<DollarSign/>} color="emerald" />
        <StatCard label="الزبائن" val={customers.length} icon={<Users/>} color="slate" isCount />
      </div>

      <div className="bg-white rounded-[2rem] border overflow-hidden">
        <div className="p-6 bg-slate-50 border-b">
          <h3 className="font-black text-slate-800">آخر الفواتير</h3>
        </div>
        <div className="divide-y">
          {sales.map(s => (
            <div key={s.id} className="p-5 flex justify-between items-center hover:bg-slate-50 transition-colors">
              <div>
                <p className="font-black text-slate-800">{s.customerName}</p>
                <p className="text-[10px] text-slate-400 font-bold">{new Date(s.timestamp).toLocaleString('ar-EG')}</p>
              </div>
              <p className="font-black text-blue-600">{s.grandTotal.toLocaleString()} {CURRENCY}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, val, icon, color, isCount }: any) => (
  <div className="bg-white p-5 rounded-2xl border flex items-center gap-4">
    <div className={`p-3 rounded-xl bg-${color}-50 text-${color}-600`}>{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase">{label}</p>
      <p className="text-lg font-black">{val.toLocaleString()} {!isCount && CURRENCY}</p>
    </div>
  </div>
);