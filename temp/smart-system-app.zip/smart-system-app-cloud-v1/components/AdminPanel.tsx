
import React, { useState } from 'react';
import { useApp } from '../store';
import { Product } from '../types';
import { CURRENCY } from '../constants';
import { 
  Plus, Edit2, Trash2, Search, X, PackagePlus, Box, 
  ArrowRightLeft, AlertTriangle, Factory, ChevronLeft,
  Settings2, TrendingDown, Warehouse
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { products, updateProduct, deleteProduct, addProduct } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [receivingProduct, setReceivingProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter(p => 
    p.name.includes(searchTerm) || p.category.includes(searchTerm)
  );

  const handleOpenModal = (p: Product | null = null) => {
    setEditingProduct(p);
    setIsModalOpen(true);
  };

  const handleReceiveProduction = (p: Product) => {
    setReceivingProduct(p);
    setIsReceiveModalOpen(true);
  };

  const handleReceiveSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!receivingProduct) return;
    const formData = new FormData(e.currentTarget);
    const addedQty = Number(formData.get('quantity'));
    
    updateProduct({
      ...receivingProduct,
      stock: receivingProduct.stock + addedQty
    });
    setIsReceiveModalOpen(false);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const costPrice = Number(formData.get('costPrice'));
    const basePrice = Number(formData.get('basePrice'));
    
    const productData = {
      name: formData.get('name') as string,
      category: formData.get('category') as string,
      costPrice,
      basePrice,
      // Note: the following limits are not in the core Product type in types.ts
      // so we only pass the properties that match Product.
      stock: Number(formData.get('stock')),
      minStock: Number(formData.get('minStock')),
      unit: formData.get('unit') as string,
      isDeleted: false,
    };

    if (editingProduct) {
      // Fix: Add isDeleted to match Product interface
      updateProduct({ 
        ...productData, 
        id: editingProduct.id, 
        ownerId: editingProduct.ownerId,
        isDeleted: editingProduct.isDeleted 
      });
    } else {
      addProduct(productData);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-500">
      {/* Search and Action Bar */}
      <div className="flex flex-col gap-3 px-2">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="ابحث عن صنف..."
            className="w-full pr-12 pl-4 py-4 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-4 rounded-2xl font-black text-sm shadow-lg shadow-blue-100 active:scale-95 transition-all"
        >
          <Plus size={20} />
          إضافة صنف جديد للمخزن
        </button>
      </div>

      {/* Products Grid - Mobile Cards */}
      <div className="grid grid-cols-1 gap-3 px-2">
        {filteredProducts.map(product => {
          const isLowStock = product.stock <= product.minStock;
          return (
            <div key={product.id} className={`bg-white rounded-3xl border ${isLowStock ? 'border-red-100 bg-red-50/10' : 'border-slate-100'} p-5 shadow-sm space-y-4`}>
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h3 className="font-black text-slate-900 text-lg">{product.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className="bg-slate-100 text-slate-500 px-2 py-0.5 rounded text-[9px] font-black">{product.category}</span>
                    <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded text-[9px] font-black">{product.unit}</span>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => handleOpenModal(product)} className="p-2 bg-slate-50 text-slate-400 rounded-xl hover:text-blue-600"><Settings2 size={18}/></button>
                  <button onClick={() => deleteProduct(product.id)} className="p-2 bg-slate-50 text-slate-400 rounded-xl hover:text-red-500"><Trash2 size={18}/></button>
                </div>
              </div>

              {/* Stock Levels & Minimums */}
              <div className="grid grid-cols-2 gap-3 bg-white/50 p-4 rounded-2xl border border-slate-50">
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase mb-1">المخزون الحالي</p>
                  <div className="flex items-center gap-2">
                    <p className={`text-2xl font-black ${isLowStock ? 'text-red-600' : 'text-slate-900'}`}>{product.stock}</p>
                    {isLowStock && <AlertTriangle size={16} className="text-red-500 animate-pulse" />}
                  </div>
                </div>
                <div className="text-right border-r pr-4">
                  <p className="text-[10px] font-black text-slate-400 uppercase mb-1">الحد الأدنى</p>
                  <p className="text-xl font-black text-slate-400">{product.minStock}</p>
                </div>
              </div>

              {/* Prices Section */}
              <div className="flex justify-between items-center px-1">
                 <div className="flex flex-col">
                    <span className="text-[9px] font-black text-slate-400 uppercase">سعر البيع</span>
                    <span className="font-black text-blue-600">{product.basePrice.toLocaleString()} {CURRENCY}</span>
                 </div>
                 <div className="flex flex-col text-left">
                    <span className="text-[9px] font-black text-slate-400 uppercase">التكلفة</span>
                    <span className="font-black text-slate-500">{product.costPrice.toLocaleString()} {CURRENCY}</span>
                 </div>
              </div>

              {/* Action Buttons for Product */}
              <div className="flex gap-2 pt-2">
                <button 
                  onClick={() => handleReceiveProduction(product)}
                  className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-emerald-50 text-emerald-600 rounded-xl font-black text-[11px] border border-emerald-100 active:scale-95 transition-all"
                >
                  <Factory size={16} />
                  استلام إنتاج
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modals */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-end sm:items-center justify-center z-[1000] p-0 sm:p-4">
          <div className="bg-white rounded-t-[2.5rem] sm:rounded-[3rem] w-full max-w-lg shadow-2xl animate-in slide-in-from-bottom duration-300 overflow-hidden max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center sticky top-0 z-10">
              <h2 className="text-xl font-black">{editingProduct ? 'تعديل الصنف' : 'إضافة صنف جديد'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-white/40 p-2"><X size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-5 text-right">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2">اسم المادة</label>
                <input name="name" required defaultValue={editingProduct?.name} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none font-black text-slate-800" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">التكلفة</label>
                  <input name="costPrice" type="number" required defaultValue={editingProduct?.costPrice} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-black text-amber-600" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">سعر المبيع</label>
                  <input name="basePrice" type="number" required defaultValue={editingProduct?.basePrice} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-black text-blue-700" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">المخزون الحالي</label>
                  <input name="stock" type="number" required defaultValue={editingProduct?.stock} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-black" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">الحد الأدنى للتنبيه</label>
                  <input name="minStock" type="number" required defaultValue={editingProduct?.minStock || 5} className="w-full px-5 py-4 bg-red-50 border border-red-100 rounded-2xl font-black text-red-600" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">الفئة</label>
                  <input name="category" required defaultValue={editingProduct?.category} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase mr-2">الوحدة</label>
                  <input name="unit" required defaultValue={editingProduct?.unit || 'قطعة'} className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" />
                </div>
              </div>

              <button type="submit" className="w-full bg-blue-600 text-white font-black py-5 rounded-[1.8rem] shadow-xl mt-4 active:scale-95 transition-all">
                {editingProduct ? 'تحديث البيانات' : 'حفظ الصنف في المخزن'}
              </button>
            </form>
          </div>
        </div>
      )}

      {isReceiveModalOpen && receivingProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-end sm:items-center justify-center z-[1000] p-0 sm:p-4">
          <div className="bg-white rounded-t-[2.5rem] sm:rounded-[3rem] w-full max-w-sm p-8 space-y-6 animate-in slide-in-from-bottom duration-300">
             <div className="text-center space-y-2">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                   <Factory size={32} />
                </div>
                <h2 className="text-xl font-black text-slate-900">استلام من الإنتاج</h2>
                <p className="text-xs text-slate-400 font-bold">إضافة كميات جديدة للمنتج: <span className="text-slate-800">{receivingProduct.name}</span></p>
             </div>

             <form onSubmit={handleReceiveSubmit} className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center block">الكمية المستلمة</label>
                   <input 
                    name="quantity" 
                    type="number" 
                    autoFocus 
                    required 
                    placeholder="0"
                    className="w-full bg-slate-50 border-2 border-transparent focus:border-emerald-500 rounded-2xl py-6 text-center text-4xl font-black outline-none transition-all"
                   />
                </div>

                <div className="flex gap-3">
                  <button type="submit" className="flex-1 py-5 bg-emerald-600 text-white rounded-2xl font-black shadow-lg shadow-emerald-100">تأكيد الاستلام</button>
                  <button type="button" onClick={() => setIsReceiveModalOpen(false)} className="px-8 py-5 bg-slate-100 rounded-2xl font-black text-slate-400">إلغاء</button>
                </div>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};
