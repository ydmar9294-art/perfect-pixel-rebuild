
import React from 'react';
import { useApp } from '../store';
import { LicenseStatus } from '../types';
import { 
  ShieldCheck, UserPlus, Key, Activity, ShieldAlert, Lock, Unlock, LogOut, 
  Copy, CheckCircle2, Clock, Calendar, Hash
} from 'lucide-react';

export const DeveloperHub: React.FC = () => {
  const { licenses, issueLicense, updateLicenseStatus, makeLicensePermanent, logout } = useApp();
  const [showForm, setShowForm] = React.useState(false);
  const [copied, setCopied] = React.useState<string | null>(null);

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12 text-right" dir="rtl">
      <div className="bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h1 className="text-4xl font-black flex items-center gap-4">نظام التراخيص <Key className="text-blue-400" /></h1>
            <p className="text-slate-400 font-bold mt-2">إصدار ومراقبة مفاتيح التفعيل السحابية.</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setShowForm(true)} className="px-8 py-4 bg-blue-600 rounded-2xl font-black shadow-xl flex items-center gap-3 active:scale-95 transition-all"><UserPlus size={20} /> إصدار ترخيص</button>
            <button onClick={logout} className="px-6 py-4 bg-white/10 rounded-2xl font-black hover:bg-red-500/20 active:scale-95 transition-all"><LogOut size={20} /></button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] p-8 border shadow-sm">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-black flex items-center gap-2"><Activity size={20} className="text-blue-600"/> سجل التراخيص الصادرة</h2>
          <div className="flex gap-4">
             <StatusBadge label="جاهز" count={licenses.filter(l => l.status === LicenseStatus.READY).length} color="blue" />
             <StatusBadge label="نشط" count={licenses.filter(l => l.status === LicenseStatus.ACTIVE).length} color="emerald" />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {licenses.map((license) => (
            <div key={license.id} className={`p-6 rounded-[2.5rem] border-2 transition-all ${license.status === LicenseStatus.SUSPENDED ? 'bg-red-50 border-red-100' : 'bg-white border-slate-50 shadow-md'}`}>
              <div className="flex justify-between items-start mb-4">
                <span className={`px-3 py-1 rounded-full text-[10px] font-black ${
                  license.status === LicenseStatus.ACTIVE ? 'bg-emerald-100 text-emerald-600' : 
                  license.status === LicenseStatus.READY ? 'bg-blue-100 text-blue-600' : 'bg-red-500 text-white'
                }`}>
                  {license.status === LicenseStatus.ACTIVE ? 'مفعل' : license.status === LicenseStatus.READY ? 'جاهز للتسليم' : 'موقوف'}
                </span>
                <span className="text-[10px] font-black text-slate-400 flex items-center gap-1">
                  {license.type === 'TRIAL' ? <Clock size={12}/> : <ShieldCheck size={12}/>}
                  {license.type === 'TRIAL' ? 'تجريبي' : 'دائم'}
                </span>
              </div>
              
              <h3 className="font-black text-slate-800 text-lg mb-1">{license.orgName}</h3>
              
              <div onClick={() => copyKey(license.licenseKey)} className="bg-slate-50 p-3 rounded-xl flex justify-between items-center cursor-pointer hover:bg-slate-100 transition-colors mb-6 group">
                <span className="font-mono font-black text-blue-600 tracking-wider">{license.licenseKey}</span>
                {copied === license.licenseKey ? <CheckCircle2 size={16} className="text-emerald-500" /> : <Copy size={16} className="text-slate-300 group-hover:text-blue-400" />}
              </div>

              {license.status !== LicenseStatus.READY && (
                <div className="flex gap-2 mb-6">
                   {license.status === LicenseStatus.ACTIVE ? (
                     <button onClick={() => updateLicenseStatus(license.id, license.ownerId, LicenseStatus.SUSPENDED)} className="flex-1 py-3 bg-red-100 text-red-600 rounded-xl text-[10px] font-black flex items-center justify-center gap-2"><Lock size={14}/> إيقاف</button>
                   ) : (
                     <button onClick={() => updateLicenseStatus(license.id, license.ownerId, LicenseStatus.ACTIVE)} className="flex-1 py-3 bg-emerald-500 text-white rounded-xl text-[10px] font-black flex items-center justify-center gap-2"><Unlock size={14}/> تفعيل</button>
                   )}
                   {license.type === 'TRIAL' && (
                     <button onClick={() => makeLicensePermanent(license.id, license.ownerId)} className="flex-1 py-3 bg-blue-50 text-blue-600 rounded-xl text-[10px] font-black flex items-center justify-center gap-2"><ShieldCheck size={14}/> تمليك</button>
                   )}
                </div>
              )}

              <div className="text-[9px] text-slate-400 font-bold border-t pt-4 flex justify-between">
                <span>أنشئ: {new Date(license.issuedAt).toLocaleDateString('ar-EG')}</span>
                {license.expiryDate && <span>ينتهي: {new Date(license.expiryDate).toLocaleDateString('ar-EG')}</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[500] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] w-full max-w-md p-8 space-y-6 animate-in zoom-in">
            <h3 className="text-xl font-black">إصدار ترخيص جديد</h3>
            <form onSubmit={async (e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              await issueLicense(fd.get('org') as string, fd.get('type') as any, Number(fd.get('days')));
              setShowForm(false);
            }} className="space-y-4">
              <input name="org" required placeholder="اسم المنشأة" className="w-full bg-slate-50 p-4 rounded-xl font-bold text-right outline-none border focus:border-blue-600" />
              <select name="type" className="w-full bg-slate-50 p-4 rounded-xl font-bold text-right outline-none border">
                <option value="TRIAL">تجريبي (Trial)</option>
                <option value="PERMANENT">دائم (Permanent)</option>
              </select>
              <input name="days" type="number" defaultValue="30" placeholder="عدد أيام التجربة" className="w-full bg-slate-50 p-4 rounded-xl font-bold text-right outline-none border" />
              <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-xl font-black shadow-lg">توليد الترخيص</button>
              <button type="button" onClick={() => setShowForm(false)} className="w-full py-4 bg-slate-100 text-slate-500 rounded-xl font-black">إغلاق</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const StatusBadge = ({ label, count, color }: any) => (
  <div className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-full border">
    <span className={`w-2 h-2 rounded-full ${color === 'blue' ? 'bg-blue-500' : 'bg-emerald-500'}`}></span>
    <span className="text-[10px] font-black text-slate-500">{label}: {count}</span>
  </div>
);
