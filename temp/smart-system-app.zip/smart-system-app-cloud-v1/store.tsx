import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback
} from 'react';
import { supabase, isSupabaseConfigured, assertSupabaseConfigured } from './lib/supabase';
import { UserRole, User, Product, License, LicenseStatus, EmployeeType } from './types';

interface Organization {
  id: string;
  name: string;
}

export interface AuthenticatedUser extends Omit<User, 'ownerId'> {}

interface AppContextType {
  user: AuthenticatedUser | null;
  role: UserRole | null;
  organization: Organization | null;
  isLoading: boolean;
  configError: boolean;

  products: Product[];
  customers: any[];
  sales: any[];
  payments: any[];
  users: User[];
  licenses: License[];

  login: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  signUp: (email: string, pass: string, code: string) => Promise<void>;
  loginDeveloper: (email: string, pass: string) => Promise<boolean>;
  refreshAllData: () => Promise<void>;

  notifications: any[];
  addNotification: (msg: string, type: 'success' | 'error' | 'warning') => void;

  createSale: (customerId: string, items: any[]) => Promise<void>;
  submitInvoice: (data: any) => Promise<void>;
  submitPayment: (data: any) => Promise<void>;
  voidSale: (saleId: string, reason: string) => Promise<void>;
  addCollection: (saleId: string, amount: number, notes?: string) => Promise<void>;
  reversePayment: (paymentId: string, reason: string) => Promise<void>;
  addCustomer: (name: string, phone: string) => Promise<void>;
  addDistributor: (
    name: string,
    phone: string,
    role: UserRole,
    type: EmployeeType
  ) => Promise<void>;
  addProduct: (product: Omit<Product, 'id' | 'ownerId'>) => Promise<void>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  issueLicense: (orgName: string, type: 'TRIAL' | 'PERMANENT', days: number) => Promise<void>;
  updateLicenseStatus: (
    id: string,
    ownerId: string | null,
    status: LicenseStatus
  ) => Promise<void>;
  makeLicensePermanent: (id: string, ownerId: string | null) => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthenticatedUser | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [configError] = useState(!isSupabaseConfigured);

  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [sales, setSales] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [licenses, setLicenses] = useState<License[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);

  const initializingAuth = useRef(false);
  const isInternalAuthOp = useRef(false);

  /* ---------------- Notifications ---------------- */

  const addNotification = useCallback((message: string, type: 'success' | 'error' | 'warning') => {
    setNotifications(prev => [{ id: Date.now(), message, type }, ...prev]);
  }, []);

  const handleError = useCallback((err: any) => {
    console.error('[App Error]:', err);
    let msg = err?.message || 'حدث خطأ غير متوقع';

    if (msg.includes('Invalid login credentials'))
      msg = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    if (msg.includes('Failed to fetch'))
      msg = 'خطأ في الاتصال بالسيرفر';

    addNotification(msg, 'error');
  }, [addNotification]);

  /* ---------------- Data Refresh ---------------- */

  const refreshAllData = useCallback(async () => {
    if (!organization?.id && role !== UserRole.DEVELOPER) return;

    try {
      assertSupabaseConfigured();

      const queries: any[] = [
        supabase.from('products').select('*').eq('is_deleted', false),
        supabase.from('view_customer_balances').select('*'),
        supabase.from('view_sales_summary').select('*').order('created_at', { ascending: false }),
        supabase.from('collections').select('*').order('created_at', { ascending: false })
      ];

      if (role === UserRole.OWNER) {
        queries.push(supabase.from('profiles').select('*'));
      }

      if (role === UserRole.DEVELOPER) {
        queries.push(
          supabase
            .from('developer_licenses')
            .select('*')
            .order('issuedAt', { ascending: false })
        );
      }

      const results = await Promise.all(queries);
      results.forEach(r => { if (r.error) throw r.error; });

      setProducts(results[0].data || []);
      setCustomers(results[1].data || []);
      setSales(results[2].data || []);
      setPayments(results[3].data || []);

      if (role === UserRole.OWNER) setUsers(results[4]?.data || []);
      if (role === UserRole.DEVELOPER) setLicenses(results[4]?.data || []);
    } catch (err) {
      console.error('refreshAllData failed:', err);
    }
  }, [organization?.id, role]);

  /* ---------------- Profile Resolver ---------------- */

  const resolveProfile = async (uid: string) => {
    try {
      setIsLoading(true);
      assertSupabaseConfigured();

      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .maybeSingle();

      if (error) throw error;
      if (!profile) throw new Error('PROFILE_NOT_READY');

      const { data: orgUser } = await supabase
        .from('organization_users')
        .select('organizations(id, name)')
        .eq('user_id', uid)
        .maybeSingle();

      setUser({
        id: profile.id,
        name: profile.full_name,
        email: '',
        role: profile.role,
        phone: ''
      });

      setRole(profile.role);
      setOrganization((orgUser as any)?.organizations || null);
    } catch (err) {
      handleError(err);
      await supabase.auth.signOut();
    } finally {
      setIsLoading(false);
    }
  };

  /* ---------------- Auth Init ---------------- */

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setIsLoading(false);
      return;
    }

    const init = async () => {
      if (initializingAuth.current) return;
      initializingAuth.current = true;

      try {
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          await resolveProfile(data.session.user.id);
        } else {
          setIsLoading(false);
        }
      } finally {
        initializingAuth.current = false;
      }
    };

    init();

    const { data: listener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (isInternalAuthOp.current || initializingAuth.current) return;

        if (session?.user && event === 'SIGNED_IN') {
          await resolveProfile(session.user.id);
        }

        if (event === 'SIGNED_OUT') {
          setUser(null);
          setRole(null);
          setOrganization(null);
          setIsLoading(false);
        }
      }
    );

    return () => listener.subscription.unsubscribe();
  }, [handleError]);

  /* ---------------- Auth Actions ---------------- */

  const login = async (email: string, pass: string) => {
    isInternalAuthOp.current = true;
    try {
      assertSupabaseConfigured();
      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: pass
      });
      if (error) throw error;
    } finally {
      isInternalAuthOp.current = false;
    }
  };

  const logout = async () => {
    isInternalAuthOp.current = true;
    try {
      setIsLoading(true);
      await supabase.auth.signOut();
      setUser(null);
      setRole(null);
      setOrganization(null);
    } finally {
      setIsLoading(false);
      isInternalAuthOp.current = false;
    }
  };

  const signUp = async (email: string, pass: string, code: string) => {
    isInternalAuthOp.current = true;
    try {
      assertSupabaseConfigured();

      const { data, error } = await supabase.auth.signUp({
        email,
        password: pass
      });

      if (error) throw error;

      if (data.user) {
        const { error: rpcError } = await supabase.rpc('use_license', {
          p_user_id: data.user.id,
          p_license_key: code
        });
        if (rpcError) throw rpcError;

        addNotification('تم تفعيل الحساب بنجاح', 'success');
      }
    } finally {
      isInternalAuthOp.current = false;
    }
  };

  useEffect(() => {
    if (organization?.id || role === UserRole.DEVELOPER) {
      refreshAllData();
    }
  }, [organization?.id, role, refreshAllData]);

  /* ---------------- Provider ---------------- */

  return (
    <AppContext.Provider
      value={{
        user,
        role,
        organization,
        isLoading,
        configError,

        products,
        customers,
        sales,
        payments,
        users,
        licenses,

        login,
        logout,
        signUp,
        loginDeveloper: async (e, p) => {
          try {
            await login(e, p);
            return true;
          } catch {
            return false;
          }
        },

        refreshAllData,
        notifications,
        addNotification,

        createSale: async (cid, items) => {
          try {
            await supabase.rpc('create_sale_rpc', { p_customer_id: cid, p_items: items });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        submitInvoice: async d => {
          try {
            await supabase.rpc('create_sale_rpc', {
              p_customer_id: d.customerId,
              p_items: d.items
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        submitPayment: async d => {
          try {
            await supabase.rpc('add_collection_rpc', {
              p_sale_id: d.saleId,
              p_amount: d.amount
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        voidSale: async (sid, r) => {
          try {
            await supabase.rpc('void_sale_rpc', { p_sale_id: sid, p_reason: r });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        addCollection: async (sid, a, n) => {
          try {
            await supabase.rpc('add_collection_rpc', {
              p_sale_id: sid,
              p_amount: a,
              p_notes: n
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        reversePayment: async (pid, r) => {
          try {
            await supabase.rpc('reverse_payment_rpc', {
              p_payment_id: pid,
              p_reason: r
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        addCustomer: async (n, p) => {
          try {
            await supabase.from('customers').insert({
              name: n,
              phone: p,
              organization_id: organization?.id
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        addDistributor: async (n, p, r, t) => {
          try {
            await supabase.rpc('add_employee_rpc', {
              p_name: n,
              p_phone: p,
              p_role: r,
              p_type: t
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        addProduct: async p => {
          try {
            await supabase.from('products').insert({
              ...p,
              organization_id: organization?.id
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        updateProduct: async p => {
          try {
            await supabase.from('products').update(p).eq('id', p.id);
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        deleteProduct: async id => {
          try {
            await supabase.from('products').update({ is_deleted: true }).eq('id', id);
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        issueLicense: async (o, t, d) => {
          try {
            await supabase.rpc('issue_license_rpc', {
              p_org_name: o,
              p_type: t,
              p_days: d
            });
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        updateLicenseStatus: async (id, _, s) => {
          try {
            await supabase.from('licenses').update({ status: s }).eq('id', id);
            await refreshAllData();
          } catch (e) { handleError(e); }
        },

        makeLicensePermanent: async (id, _) => {
          try {
            await supabase.from('licenses').update({ type: 'PERMANENT' }).eq('id', id);
            await refreshAllData();
          } catch (e) { handleError(e); }
        }
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};