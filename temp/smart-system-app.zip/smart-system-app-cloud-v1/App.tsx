
import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './store';
import { UserRole, EmployeeType } from './types';
import { Layout } from './components/Layout';
import { DistributorView } from './components/DistributorView';
import { OwnerDashboard } from './components/OwnerDashboard';
import { AccountantView } from './components/AccountantView';
import { DeveloperHub } from './components/DeveloperHub';
import { 
  ShieldCheck, Eye, EyeOff, Loader2, Terminal, Store,
  AlertCircle, CheckCircle2, ShieldAlert
} from 'lucide-react';

const ToastManager: React.FC = () => {
  const { notifications } = useApp();
  const [visibleToasts, setVisibleToasts] = useState<any[]>([]);

  useEffect(() => {
    if (notifications.length > 0) {
      setVisibleToasts(prev => [...prev, notifications[notifications.length - 1]]);
      const timer = setTimeout(() => {
        setVisibleToasts(prev => prev.slice(1));
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [notifications]);

  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[9999] flex flex-col gap-3 w-full max-w-sm px-4">
      {visibleToasts.map((toast) => (
        <div key={toast.id} className={`flex items-center gap-3 p-4 rounded-2xl shadow-2xl border animate-in slide-in-from-top duration-300 ${
          toast.type === 'error' ? 'bg-red-50 border-red-100 text-red-700' :
          toast.type === 'warning' ? 'bg-amber-50 border-amber-100 text-amber-700' :
          'bg-emerald-50 border-emerald-100 text-emerald-700'
        }`}>
          {toast.type === 'error' ? <AlertCircle size={20} /> : <CheckCircle2 size={20} />}
          <p className="flex-1 font-black text-sm text-right leading-relaxed">{toast.message}</p>
        </div>
      ))}
    </div>
  );
};

const ConfigErrorView: React.FC = () => (
  <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-8 text-center" dir="rtl">
    <div className="max-w-md space-y-6">
      <div className="w-20 h-20 bg-red-500 rounded-3xl flex items-center justify-center text-white mx-auto shadow-2xl">
        <ShieldAlert size={40} />
      </div>
      <h1 className="text-2xl font-black text-white">خطأ في إعدادات النظام</h1>
      <p className="text-slate-400 font-bold leading-relaxed">
        لم يتم العثور على مفاتيح الربط البرمجية (Supabase Keys). 
        يرجى التأكد من ملف .env أو إعدادات Capacitor.
      </p>
    </div>
  </div>
);

const LoginView: React.FC = () => {
  const { login, signUp, loginDeveloper, isLoading, addNotification } = useApp();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [activationCode, setActivationCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [localLoading, setLocalLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();
    const cleanPass = password.trim();
    
    if (!cleanEmail || !cleanPass) {
      addNotification("يرجى إدخال كافة البيانات", "warning");
      return;
    }

    setLocalLoading(true);
    try {
      if (isDeveloperMode) {
        const success = await loginDeveloper(cleanEmail, cleanPass);
        if (!success) addNotification("بيانات المطور غير صحيحة", "error");
      } else {
        if (mode === 'signup') {
          if (!activationCode.trim()) {
            addNotification("كود التفعيل مطلوب", "error");
            return;
          }
          await signUp(cleanEmail, cleanPass, activationCode.trim().toUpperCase());
        } else {
          await login(cleanEmail, cleanPass);
        }
      }
    } catch (err: any) {
      console.error("Login attempt failed:", err);
      addNotification(err.message || "فشلت عملية الدخول", "error");
    } finally {
      setLocalLoading(false);
    }
  };

  return (
    <div className={`min-h-screen flex flex-col font-['Tajawal'] relative ${isDeveloperMode ? 'bg-[#0f172a]' : 'bg-slate-50'}`} dir="rtl">
      <div className={`${isDeveloperMode ? 'bg-slate-900 border-b border-white/5' : 'bg-[#1a1f2e]'} pt-14 pb-12 px-6 relative overflow-hidden flex flex-col items-center shrink-0`}>
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
        <div className={`w-20 h-20 rounded-[1.8rem] flex items-center justify-center shadow-2xl mb-5 z-10 border-4 border-white/5 ${isDeveloperMode ? 'bg-blue-600' : 'bg-gradient-to-br from-blue-500 to-indigo-600'}`}>
          {isDeveloperMode ? <Terminal size={40} className="text-white" /> : <ShieldCheck size={40} className="text-white" />}
        </div>
        <h1 className="text-3xl font-black text-white mb-1 tracking-tight z-10">
          {isDeveloperMode ? 'بوابة المطورين' : 'النظام الذكي'}
        </h1>
        <p className="text-white/60 text-[11px] font-medium z-10 mb-8 uppercase tracking-widest">Smart Sales Pro v2</p>
      </div>

      <div className="max-w-md w-full mx-auto px-6 -mt-6 z-20 flex-1 flex flex-col pb-24">
        <div className="bg-white rounded-[2.5rem] shadow-xl border overflow-hidden">
          <div className="flex bg-slate-50 p-1.5 m-6 rounded-2xl border">
            {!isDeveloperMode ? (
              <>
                <button onClick={() => setMode('login')} className={`flex-1 py-3.5 rounded-xl font-black text-sm transition-all ${mode === 'login' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}>تسجيل الدخول</button>
                <button onClick={() => setMode('signup')} className={`flex-1 py-3.5 rounded-xl font-black text-sm transition-all ${mode === 'signup' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}>تفعيل نظام</button>
              </>
            ) : (
              <div className="w-full text-center py-3.5 font-black text-slate-800 text-sm">واجهة التطوير التقني</div>
            )}
          </div>
          
          <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-4">
            <input 
              type="email" 
              placeholder="البريد الإلكتروني" 
              value={email} 
              disabled={localLoading}
              className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 text-right font-bold outline-none focus:ring-2 focus:ring-blue-100 transition-all" 
              onChange={e => setEmail(e.target.value)} 
            />
            <div className="relative">
              <input 
                type={showPassword ? "text" : "password"} 
                placeholder="كلمة المرور" 
                value={password} 
                disabled={localLoading}
                className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 text-right font-bold outline-none focus:ring-2 focus:ring-blue-100 transition-all" 
                onChange={e => setPassword(e.target.value)} 
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {mode === 'signup' && (
              <input 
                type="text" 
                placeholder="كود تفعيل المنشأة" 
                value={activationCode} 
                disabled={localLoading}
                className="w-full bg-blue-50 border-2 border-blue-100 rounded-2xl px-6 py-4 text-right font-black text-blue-700 outline-none uppercase" 
                onChange={e => setActivationCode(e.target.value)} 
              />
            )}
            <button 
              type="submit" 
              disabled={localLoading || isLoading} 
              className="w-full py-5 bg-[#1a1f2e] text-white rounded-2xl font-black text-lg flex items-center justify-center gap-3 active:scale-95 transition-all disabled:opacity-50"
            >
              {(localLoading || isLoading) ? <Loader2 size={24} className="animate-spin" /> : mode === 'login' ? 'دخول النظام' : 'تفعيل الحساب'}
            </button>
          </form>
          
          <div className="px-8 pb-6 border-t border-slate-50 pt-4">
             <button onClick={() => setIsDeveloperMode(!isDeveloperMode)} className="w-full text-xs font-bold text-slate-300 hover:text-blue-400 transition-colors uppercase tracking-widest">
               {isDeveloperMode ? 'العودة لواجهة المستخدم' : 'الدخول كـ مطور نظام'}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const ViewManager: React.FC = () => {
  const { user, organization, logout } = useApp();
  if (!user) return <LoginView />;

  if (user.role === UserRole.OWNER && !organization) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 text-center" dir="rtl">
        <div className="max-w-md space-y-6">
          <div className="w-24 h-24 bg-red-500 rounded-[2.5rem] flex items-center justify-center text-white mx-auto shadow-2xl">
            <Store size={48} />
          </div>
          <h2 className="text-3xl font-black text-white">لا توجد منشأة نشطة</h2>
          <p className="text-slate-400 font-bold text-lg leading-relaxed">لم يتم ربط حسابك بأي منشأة تجارية. يرجى مراجعة الدعم الفني.</p>
          <button onClick={logout} className="w-full py-4 bg-white/10 text-white rounded-2xl font-black mt-8 active:scale-95 transition-all">تسجيل الخروج</button>
        </div>
      </div>
    );
  }

  switch (user.role) {
    case UserRole.OWNER: return <OwnerDashboard />;
    case UserRole.EMPLOYEE:
      return user.employeeType === EmployeeType.ACCOUNTANT ? <AccountantView /> : <DistributorView />;
    case UserRole.DEVELOPER: return <DeveloperHub />;
    default: return <OwnerDashboard />;
  }
};

const MainContent: React.FC = () => {
  const { user, isLoading, configError } = useApp();

  if (configError) return <ConfigErrorView />;

  if (isLoading) return (
    <div className="h-screen flex flex-col items-center justify-center bg-[#1a1f2e]">
      <Loader2 size={48} className="animate-spin text-blue-500 mb-4" />
      <p className="text-white/20 font-black text-[10px] uppercase tracking-[0.3em]">Smart System Initialization</p>
    </div>
  );

  return (
    <>
      <ToastManager />
      {!user ? <LoginView /> : <Layout><ViewManager /></Layout>}
    </>
  );
};

const App: React.FC = () => (
  <AppProvider>
    <MainContent />
  </AppProvider>
);

export default App;
