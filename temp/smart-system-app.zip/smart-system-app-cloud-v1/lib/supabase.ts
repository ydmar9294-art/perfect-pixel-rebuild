
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Add type definition for Vite's import.meta.env
interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl !== 'undefined' && 
  supabaseUrl.startsWith('http')
);

let supabaseInstance: SupabaseClient | null = null;

if (isSupabaseConfigured) {
  supabaseInstance = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: window.localStorage
    }
  });
}

export const supabase = supabaseInstance as SupabaseClient;

export function assertSupabaseConfigured(): void {
  if (!isSupabaseConfigured || !supabase) {
    throw new Error("Configuration missing: VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY is not defined.");
  }
}
