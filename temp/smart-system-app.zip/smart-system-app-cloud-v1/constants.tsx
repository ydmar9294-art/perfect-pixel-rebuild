
import { UserRole, Product, User } from './types';

export const INITIAL_PRODUCTS: Product[] = [];

/**
 * Removed hardcoded INITIAL_USERS.
 * Users are now managed exclusively through Firebase Auth and the 'users' collection 
 * in Firestore via activation codes or system admin claims.
 */
export const INITIAL_USERS: User[] = [];

export const PRODUCT_CONDITIONS = [
  { value: 'excellent', label: 'ممتاز (يعود للمخزن)' },
  { value: 'very_good', label: 'جيد جداً (يعود للمخزن)' },
  { value: 'good', label: 'جيد (يعود للمخزن)' },
  { value: 'bad', label: 'سيء (لا يعود)' },
  { value: 'damaged', label: 'تالف (إتلاف)' },
];

export const CURRENCY = 'ل.س';
